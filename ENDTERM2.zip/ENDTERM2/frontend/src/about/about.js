import React from 'react'

export default function About() {
  return (
    <div style={{backgroundImage:"url('https://t3.ftcdn.net/jpg/02/96/69/22/360_F_296692203_k4lOpOt8mAcYpKzicNmJTpnsE9ZdwyHX.jpg')",backgroundAttachment:"fixed",backgroundSize:"cover"}}>
      
      <div style={{height:"92vh"}}>
        <h1 style={{textAlign:"center",color:"white"}}>About Us</h1>
      <div >
           <p><b>
           </b></p> 
      </div>
      </div>
    </div>
  )
}