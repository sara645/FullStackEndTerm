import React from 'react'

export default function Develop() {
    
  return (
    <div>
        <nav class="bg-dark">
            <div class="container" style={{textAlign:"center",color:"white",height:"2cm"}}>
               <p> Create By : Sara Gupta (2010990645)<br/>
                sara0645.be20@chitkara.edu.in<br/>
                </p> 
            </div>
        </nav>
    </div>
  )
}
